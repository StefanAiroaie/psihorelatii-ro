'use client'
import { createContext, useContext, useEffect, useState } from 'react';

// Consent configuration
const CONSENT_VERSION = '1.0';
const CONSENT_MAX_AGE_DAYS = 365; // re-prompt anual

const CookieConsentContext = createContext();

export const CookieConsentProvider = ({ children }) => {
    const [cookiesAccepted, setCookiesAccepted] = useState(undefined);

    // Citește decizia (cu versionare + expirare)
    useEffect(() => {
        const storedConsent = localStorage.getItem('cookiesAccepted');
        const storedVersion = localStorage.getItem('cookiesVersion');
        const storedTs = localStorage.getItem('cookiesTimestamp');

        const isExpired = () => {
            if (!storedTs) return true;
            const then = Number(storedTs);
            const days = (Date.now() - then) / (1000 * 60 * 60 * 24);
            return days > CONSENT_MAX_AGE_DAYS;
        };

        if (!storedConsent || storedVersion !== CONSENT_VERSION || isExpired()) {
            setCookiesAccepted(undefined); // reafișează bannerul
            return;
        }
        setCookiesAccepted(storedConsent === 'true');
    }, []);

    // Propagă schimbarea consimțământului (Consent Mode v2 + dataLayer)
    useEffect(() => {
        if (typeof window === 'undefined') return;
        if (cookiesAccepted === undefined) return;
        const state = cookiesAccepted ? 'granted' : 'denied';

        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({ event: 'cookie_consent_updated', cookiesAccepted });

        if (typeof window.gtag === 'function') {
            window.gtag('consent', 'update', {
                ad_storage: state,
                analytics_storage: state,
                ad_user_data: state,
                ad_personalization: state
            });
        }
    }, [cookiesAccepted]);

    const updateStorage = (accepted) => {
        localStorage.setItem('cookiesAccepted', accepted ? 'true' : 'false');
        localStorage.setItem('cookiesVersion', CONSENT_VERSION);
        localStorage.setItem('cookiesTimestamp', String(Date.now()));
    };

    const acceptCookies = () => {
        if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
            window.gtag('consent', 'update', {
                ad_storage: 'granted',
                analytics_storage: 'granted',
                ad_user_data: 'granted',
                ad_personalization: 'granted'
            });
        }
        updateStorage(true);
        setCookiesAccepted(true);
    };

    const rejectCookies = () => {
        if (typeof window !== 'undefined' && typeof window.gtag === 'function') {
            window.gtag('consent', 'update', {
                ad_storage: 'denied',
                analytics_storage: 'denied',
                ad_user_data: 'denied',
                ad_personalization: 'denied'
            });
        }
        updateStorage(false);
        setCookiesAccepted(false);
    };

    const reopenPreferences = () => {
        localStorage.removeItem('cookiesAccepted');
        localStorage.removeItem('cookiesVersion');
        localStorage.removeItem('cookiesTimestamp');
        setCookiesAccepted(undefined);
    };

    return (
        <CookieConsentContext.Provider
            value={{ cookiesAccepted, acceptCookies, rejectCookies, reopenPreferences }}
        >
            {children}
        </CookieConsentContext.Provider>
    );
};

export const useCookieConsent = () => useContext(CookieConsentContext);